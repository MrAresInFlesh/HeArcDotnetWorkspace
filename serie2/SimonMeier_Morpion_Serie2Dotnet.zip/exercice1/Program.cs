using System;

namespace exercice1
{
    class Program
    {
        static void Main(string[] args)
        {
            Game scene = new Game();
        }
    }
}
